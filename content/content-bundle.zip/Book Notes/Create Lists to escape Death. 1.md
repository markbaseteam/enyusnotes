[A quote from Umberto Eco’s interview with Der Spiegel](http://www.spiegel.de/international/zeitgeist/spiegel-interview-with-umberto-eco-we-like-lists-because-we-don-t-want-to-die-a-659577.html) 

SPIEGEL: But, in doing so, doesn’t he stray from poetry?

Eco: At first, we think that a list is primitive and typical of very early cultures, which had no exact concept of the universe and were therefore limited to listing the characteristics they could name. But, in cultural history, the list has prevailed over and over again. It is by no means merely an expression of primitive cultures. A very clear image of the universe existed in the Middle Ages, and there were lists. A new worldview based on astronomy predominated in the Renaissance and the Baroque era. **And there were lists. And the list is certainly prevalent in the postmodern age. It has an irresistible magic.**

SPIEGEL: But why does Homer list all of those warriors and their ships if he knows that he can never name them all?

Eco: Homer’s work hits again and again on the topos of the inexpressible. People will always do that. We have always been fascinated by infinite space, by the endless stars and by galaxies upon galaxies. How does a person feel when looking at the sky? He thinks that he doesn’t have enough tongues to describe what he sees. Nevertheless, people have never stopping describing the sky, simply listing what they see. Lovers are in the same position. They experience a deficiency of language, a lack of words to express their feelings. But do lovers ever stop trying to do so? They create lists: Your eyes are so beautiful, and so is your mouth, and your collarbone One could go into great detail.

SPIEGEL: Why do we waste so much time trying to complete things that can’t be realistically completed?

Eco: We have a limit, a very discouraging, humiliating limit: death. That’s why we like all the things that we assume have no limits and, therefore, no end. It’s a way of escaping thoughts about death. **We like lists because we don’t want to die.**