## Adrian Hon

### Summary

The book discusses the concept of gamification and its effects on society. It covers topics such as behaviorism, humanistic psychology, self-determination theory, variable reinforcement ratios, and the compulsion loop. The book argues that the use of gamification as an authoritarian technique and discusses how governments are using it to control citizens. It also discusses the importance of subsidiarity, transparency, and trust in democracies. The book ends by cautioning against reducing human thought and motivation to a behaviorist world, where people are treated like NPCs instead of individuals.

---
- Behaviorism
	- radical behaviorism: humans like animals, are solely the product of our environment
	- our behavior is purely affected by extrinsic motivation such as rewards and punishment
- Humanistic Psychology:
	- Intrinsic motivation, such as things that are joyful for us to do, makes us behave in certain ways

- Variable Reinforcement Ratios:
	- Reinforce a desired behaviour by giving rewards at unpredictable intervals
	- Example: Slot Machines

- Self-Determination theory
	- Autonomy: Ability to determine one's own path
	- Competence: Experience Mastery
	- Relatedness: Interacting with and caring for others

- Points and rewards and achievements are "mere gestures that provide structure and measure progress"
	- Take away the points and rewards in the most gamified experiences, and you're left with nothing

**Effectiveness** = *gameplay quality* * *accessibility* * *pre-existing intrinsic motivation*

- Scalar Fallacy: belief that things in the real world have a single dimension ordering of "goodness" such that a hotel with a high customer rating is obviously "better" than one with a lower rating
	- When collapsing the complexity of these things into just one dimension, you lose a vast amount of context and make an awful lot of assumption on behalf of your audience

Companies invest heavily in productivity gamification, or work place monitoring, in the trend of obsessive metrics on measuring everything (Movement, time away from desk, screen activity) 

**Not because it makes mundane work more fun or interesting, but because it can decrease their costs**
- These productivity APIs can often replace middle level managers
- APIs sets targets and pace for workers, that are often unrealistic to match 100%
	- Offloads the feeling of responsibility when tasks are not completed to the workers
	- Often phrased in a way as "oh too bad, you missed out on completing another trip for an extra $10, maybe next time"

- Compulsion loop:
	- First, make players *anticipate a reward* (like a more powerful sword or the prospect of travelling to a new game area)
	- Second, *give them a challenge* (like killing monsters or solving a puzzle)
	- Lastly, *reward the players after completing challenge*, and unlocks yet more challenges and more anticipated rewards
	- Can lead to compulsive behavior sometimes addictive behavior

**Lewis Mumford warned over half a century ago (American Historian and Philosopher of Technology)**
- "Two technologies have recurrently existed side by side: one authoritarian, the other democratic, the first system-centered, immensely powerful, but inherently unstable, the other mancentered, relatively weak, but resourceful and durable."
	-  We are approaching a inflection point where, unless we radically change our present course, democratic technics will be completely suppressed or supplanted. There will be no more residual autonomy, or used as a tool for political drama
	- "like national ballotting for already chosen leaders in totalitarian countries"
	- The moment that citizens stop exercising their individual autonomy over technologies such as industrial farming and mass media, to the few invisible and unaccountable elites, freedom will be stripped, there would be no room for backtracking, and everyone would be coerced into behaving as the authoritarian systems dictated.
- Mumford saw our tolerance for authroitarian technics:
	- Authoritarian system fairly described as one that is inescapable, and constantly reinforces behaviour
	- our tolerance for authoritarian technics is a part of a "magnificent bribe"
		- in exchange for everything we desire (food, housing, swift transportation, instantaneuous communication, medical care, entertainment, education)
		- we must "not merely ask for nothing that the system does not provie, but likewise agree to take everything offered, duy processed and fabricated, homogenized and equalized, in the precise quantities that the system, rather than the person, requires"
		- the price we pay for this bribe is that our own behaviour is also controlled
	- He was not against technology, but want it to be used and designed and controlled on a more personal level. And also wanted politicians and legislators to care more about technology in itself.

- Gamification increasingly used as an authoritarian technic
	- Goverments across the world are experimenting with gamification, framed as harmless "nudges" to make citizens behalf better
	- No different than companies "using the veneer of gamification to reduce wages and control workers"
	- China's social credit score
		- Can blacklist individuals from accessing air travel and high-speed train ravel, premium insurance, private schools and or buying real estate
		- Plan to integrate with a "digital yuan", CBDC to make it easier to instantly issue and collect fines as soons as an infractions is detected, or issue monetary rewards for good behaviour.
	- Under the relenting constant gaze of mass surveillance, people are no longer able to cultivate their own beliefs and monitor their own thoughts and feelings. 
		- Forced to organize oneself and ones life around the aim of pleasing the state, an AI overseer, and the judgements of others. Along the way losing sight of what one actually believe about goodness and virtue, as independent judgements about morals lose its motivational power.

- Lenin, in 1917 proposed a theory of "socialist competition" to motivate factories to produce more, by means of points and levels and medals.
	- Gamifications of this manner predated computers and exists beyond capitalism

- Governments and authorities are gamifying the lives of millions without heir consent
- Deminishing the lives of people into data points to be manipulated like NPCs in a video game
- Acceleration in technological development will only allow this type off gamification to be more invasive and centralized

**Subsidiarity- the principle of allowing the individual members of a large organization to make decisions on issues that affect them, rather than leaving those decisions to be made by the whole group**.

- Without subsidiarity and transparency in democracies, there can be no trust. When there is no longer trust in the world, it is the fertile ground for conspiracy theories.


"**I've done my research**"
>We are all capable of believing things which we know to be untrue, and them, when we are finally proved wrong, impudently twisting the facts so as to show that we were right. Intellectually, it is possible to carry on this process for an indeifinite time: the only check on it is that sooner or later a falsebelieve bumps up against solide reality, usually on a battlefield.
>	- George Orwell, "In Front of Your Nose" (1946)

>All the world's a stage, and all the men and women merely players.
>-William Shakespeare


We cant help but imagine life as a game now: 
- A constant ompetition where we all begin as equals, where luck is present but skill can overcome any obstacle, where cheating is punished but if you play right, you'll win.

**Kriegsspiel**- Wargame, used by the prussian army in the nineteenth century to teach battlefield tactics.

**Robinhood**
- The stock market is a game, and they want everyone to play
- Robinhood offers commission free trading, it uses PFOF, payment for order flow to make money
- They are paid whenever a user makes a trade, and the company is strongly incentivized to encourage its users to make as many trades as possible

> Twitter is a multiplayer online game in which you choose an avatar and role play a persona loosely based on your own, attempting to accrue followers by pressing lettered buttons to form interesting sentences
> 	-Charlie Brooker, creator of *Black Mirror*

- Social media's ability to focus and amplify attention enables news that used to take hours or days to be published  or brodcasted to now race around the world in minutes
- *If the marketplace is gamified, so too is the marketplace of ideas*
	- Facebook's algo reward lies and exaggerations on subjects 
	- the extreme posts receive more engagement, resulting in amplification to a larger audience
	- It is similar to the compulsion loops designed into video games

> Socia media has become the worlds new public square. It has democratised the ability to publish information and allowed any individual to get their message out to billions, a priviledge one afforded only to the rich and powerful. It is too important to be played and manipulated like a game

> To use games as our new system of the world is to reduce the richness of human thought and motivation to a barren, behaviourist world of reward and punishment, where trating other people like they are NPCs isnt only justified, its desirable.


- Young men will be so entertained by cheap or free video games that they won't see the value in filling those positions at the bottom of the employment market
	- already seen in the increase in the amount of Twitch game streamers
	- If automation eventually reduces the number of jobs available in the economy, perhaps games might become subsidized as a form of social control, cutting edge bread and circuses to keep people happy
		- The Roman coliseum
	- Research already being conducted to distract hackers from causing damage to real servers by creating gamified, narrative based "honeypot" servers containing fake but enticing data
		- why not extend the principle to other areas

**Virtual pilgrimages** - appealed to the women who had to stay home, highly sophisticated, with physical maps helping readers visualize where they were talking. Pilgrimages were thought to be indulgence
- They were a counterweight to penances in purgatory, but it was unclear how they transferred into the afterlife
- they weren't accepted by everyone
	- Before the reformation, criticisms had little effect
	- Before the reformation, natural threats like the Black Death, political turmoil, poor weather, and war meant the theoretical flaws of indulgences were out-weighed by the fear of death. 
	- Indulgences gave people more effective control over their future in the afterlife, as you did not have to rely on third parties or fortune if you could earn or buy your way though purgatory
	- If a game, or an indulgence promises salvation, who wouldn't take it.

> Just because much of advertising is ineffective doesn't mean we should look the other way when billions are spent on tobacco and gambling adverts

> There is a fine line for what constitutes coercion in gamification

