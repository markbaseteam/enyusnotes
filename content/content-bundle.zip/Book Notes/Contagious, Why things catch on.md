---
quickshare-date: 2023-03-19 20:06:09
quickshare-url: "https://noteshare.space/note/clfg2gigv1180801pjf0kn9e9u#TjmOCorvbeoSZWHt9cClRGqNcQvxkKCkd9XORBeIv58"
---
## Jonah Berger

### Summary

Jonah Berger looks at why certain products, ideas, and behaviors catch on and become popular. He suggests that social epidemics are driven by the efforts of a few people and that products and ideas become popular because they are better, more affordable, or more heavily advertised. He also suggests that word of mouth is the primary factor behind 20-50% of all purchasing decisions and is more effective than a traditional advertisement. He then looks at the psychology of sharing and the idea that people love to talk about themselves and their experiences. He then looks at six principles of contagiousness, including social currency, self-sharing, triggers, emotion, arousal, and public. He suggests that people are more likely to talk about things that make them look good and that triggers and cues lead people to talk, choose, and use. He also looks at the power of awe and how positive articles are more likely to be shared than negative ones. Finally, he suggests that making things more observable makes them easier to imitate and more likely to become popular.

### Introduction
- Why things catch on
	- Good food and great atmosphere wouldn't be enough, more than 25% of restaurants fail within twelve months of opening their doors. Sixty percent are gone within the first 3 years.
	- Barclays Prime steak house
		- Got people to start talking about this new restaurant opening by offering a hundred-dollar cheesesteak
		- a sandwich that is available for 4-5 bucks at hundreds of shops
	- **Wein did not just create another cheesesteak, he created a conversation piece**

- Why do products, ideas, and behaviors catch on?
	- Examples: Nonfat Greek Yogurt, Low Fat diets, Low-carb Craze
	- **Social Epidemics**
		- are driven by the efforts of a handful of exceptional people (mavens, connectors, salesmen)
	- Instances where products, ideas, and behaviors *diffuse* through a population. 
		- Starts from a small set of individuals and spread like a virus

- Products and Ideas become popular 
	- because they are just **plain better**
		- flat screen TV v.s. bulky TV
	- because they offer **attractive pricing**
		- people prefer paying less rather than more
	- because of **advertisements**
- But unable to explain why certain names become more popular, like others
	- same can be said for ideas on YouTube
		- there is no difference in price, all free to watch
		- few videos get advertising push
		- high production videos make little to no difference in virality, most videos are blurred or out of frame

**Social Transmission** - Social influence and word of mouth
- people love sharing stories, news and information with those around them
- people share more than 16,000 words per day 
- Word of mouth is the primary factor behind 20-50% of all purchasing decisions
	- more effective than traditional advertisement 
		- more persuasive, more objective, candid reviews, which are easier to trust
		- more targeted,  companies advertise to a target market that might miss, word of mouth naturally directed to interested audience
			- We tend to select particular people who we think would find that given piece of information most relevant and useful
		- customers referred by their friends spend more, shop faster, and are more profitable overall

Dialed in targeting (example)
- book publishers typically gift free copy of books to professors
- yes word of mouth would be spread
- more effective for book publishers to give 2 copies, 
	- rather than sending books to everyone, they let the select few do the targeting for them.

What percent of word of mouth do you think happens online?
- Instinctually, most people would say 50%
- **The actual number is 7%** 
	- We tend to overestimate online word of mouth because it is easier to see and measure
	- There is no recording of offline conversations
	- Online conversations might reach more people, 
		- face to face convos are usually 1-1
		- avg tweet or Facebook status is sent to 100 people, but not all of these potential recipients will receive the message
	- just putting up content online, does not mean anyone will notice or spread the word
		- 50% of YouTube videos have < than 500 views, only 0.3% videos get > than 1 mill views
- Why do certain things get talked about and shared more than others?
	- Psychology of sharing, science of social transmission
	- certain stories are more contagious, certain rumorss are more infectious
		- 1 in 10 people in America tells the other 9 how to vote, where to eat, what to buy
		- Marketers spend millions to find these so-called opinion leaders
	- What is overlooked and neglected, a much more obvious driver of sharing, the message
		- certain jokes are funny no matter who tells them
		- contagious content is like that, no matter if it's told by someone who's really persuasive



## *Six Principles of Contagiousness*

### Social Currency
*How does it make people look to talk about a product or idea? Most people would rather look smart than dumb, rich than poor, and cool than geeky. Just like the clothes we wear and the cars we drive, what we talk about influences how others see us. It's social currency. Knowing about cool things---like a blender that can tear through an iphone---makes people seem sharp and in the know. So to get people talking we need to craft messages that help them achieve these desired impressions. We need to find our inner remarkability and make people feel like insiders. We need to leverage game mechanics to give people ways to achieve and provide visible symbols of status that they can show to others.*

- If something is supposed to be secret, people might well be *more* likely to talk about it. The reason? **Social Currency**

- "Self-Sharing" follows us throughout our lives
	- Social Media and social networks have become so popular because of this
	- Why do people talk so much about their own attitudes and experiences?
	- its more than just vanity; We are actually wired to find it pleasurable
		- Jason Mitchell and Diana Tamir (Harvard Neuroscientists) found that disclosing information about the self is intrinsically rewarding. 
		- They found that sharing personal opinions activated the same brain circuits that respond to rewards like food and money. So talking about what you did, feels just as good as eating icecream
		- Talking about yourself is so pleasurable that people are willing to pay money to do it.
		- (A trial ran by Mitchell and Tamir where they offered people a certain amount of money to "hang out for a few seconds", and less money if they chose to "answer a question about themselves")
			- Overall, people were willing to take a 25c pay cut to share their thoughts
			- *I think claiming that people are directly willing to pay for sharing their opinions is not neccesarily the right claim given this study. Yes, classical economists will argue that forgoing 25c is the same as paying 25c, in opportunity costs. But in behavioral economics point of view, if both options given to participants offered a set amount of monetary return, it could just mean that getting to share their personal opinions gave them "marginal utility" on top of the expected utility of receiving money, this total utility of choosing to share personal opinion, outweighed the total utility (in this case only expected utility) of choosing to hang out for few seconds and doing nothing. *

- word of mouth is a prime tool for making a good impression
- as we have reservations to talk about things that would make ourselves or someone else look bad
- Social currency, are used by people to achieve desired positive impressions among their families, freinds and colleagues.

Snapple facts:
- "a ball of glass will bounce higher than a ball of rubber"
- after finding this out, most people would want to share it with their friends

Mark Rubenstein, executive VP of Snapples ad agency came up with the idea of putting trivia facts under the caps, as it was unused real estate. Visible only after customers have purchased and opened the bottles.

Terrible jokes were tried in the beginning, so it was hard to tell if strategy or jokes were failing.

Remarkable things - unusual, extraordinary, worthy of notice or attention, novel, surprising, extreme, interesting
Remarkable things are worthy of remark - worthy of mention. 

Less than 10 percent of miles are redeemed every year. It is estimated that more than 10 trillion frequent flier miles are sitting in accounts, unused. Enough to travel to the moon and back 19.4 million times.
If people are not using the miles, why are people so passionate about racking up miles? **Because its a fun game**

Game mechanics can motivate us intrinsically. but also can motivate us on a interpersonal level by encouraing social comparison. 

>A few years ago, students at Harvard University were asked to make a seemingly straightforward choice: which would they prefer, a job where they made $50,000 a year (option A) or one where they made $100,000 a year (option B)?
	  Seems like a no-brainer, right? Everyone should take option B. But there was one catch. In option A, the students would get paid twice as much as others, who would only get $25,000. In option B, they would get paid half as much as others, who would get $200,000. So option B would make the students more money overall, but they would be doing worse than others around them.
	What did the majority of people choose?
	Option A. They preferred to do better than others, even if it meant getting less for themselves. They chose the option that was worse in absolute terms but better in relative terms.

- Game mechanics boost word of mouth because people talk about things to show off their achievements. At the same time, they are also talking about brands, (Twitter or Delta), or domains (golf or the SAT) where they achieved.
- ==Great game mechanics can even create achievements out of nothing. Airlines turned loyalty into a status symbol. Foursquare made it a mark of distinction to be a fixture at the corner bar.
- Game makers managed to convince people to proclaim loudly, even boast about their achievements

>[!tip]
>Make People Feel Like Insiders
>
>	Instead of marketing the product, brand, or initiative directly, company uses the **contest** to get people who want to win do the marketing themselves

- scarcity and exclusivity help products catch on by making them seem more desirable.
	- boost word of mouth by making people feel like insiders
	- getting something not everyone has, makes them feel special, unique, and high status.
	- ==they will like the product and service even more, and tell others about it
	- *having insider knowledge is social currency*
- Using scarcity and exclusivity early on and then relaxing the restrictions later is a particularly good way to build demand
- Managing the disappointments
	- People are used to getting what they want.
	- Use "no.....but..."
	- maintain the allure while also maintaining customer satisfaction 

>[!cite]
> No one paid me for the hours I spent, and my friends and I didn't even have a bet riding on the outcome. We were just playing for fun. And, of course, bragging rights. But since doing better than others is social currency, everyone was motivated to do well. Even without a monetary incentive.
> 
> The moral? People don't need to be paid to be motivated. Managers ofter default to monetary incentives when trying to motivate employees. 
> 
> 	Fantasy Football


---
  
### Triggers
*How do we remind people to talk about our products and ideas? Triggers are stimuli that prompt people to think about related things. Peanut butter reminds us of jelly and the word "dog" reminds us of the word "cat". If you live in Philadelphia, seeing a cheese steak might remind you of the hundred-dollar one at Barclay Prime. People often talk about whatever comes to mind, so the more often people think about a product or idea, the more it will be talked about. We need to design products and ideas that are frequently triggered by the environment and create new triggers by linking our products and ideas to prevalent cues in that environment. Top of mind leads to tip of tongue*

- Every day, the average American engages in more than sixteen word-of-mouth episodes, separate conversations where they say something positive or negative about an organization, brand, product, or service

>[!hint] Hypothesis
>
> If interest and interesting products drives word of mouth (products can be interesting because they're novel, exciting, or confound expectations in some way)
> 
> Then action flicks and Disney World should be talked about more than Cheerios and dish soap.
> ==Intuitively it makes sense
> Interesting things are entertaining and reflect positively on the person talking about them==
>
> 	we when talk to others, we communicate information, but also something about ourselves
> 	
> 	**There's a difference between immediate and ongoing word of mouth**

**Sights smells, and sounds can *trigger* related thoughts and ideas, making them more top of mind**
- accessible thoughts and ideas lead to *action*

When people voted in schools, they are more likely to vote in favor of increasing taxes to support public schools. If where they vote didn't matter, then the distribution should be the same no matter where they voted.

==Triggers and cues lead people to talk, choose, and use. Social Currency gets people talking, but Triggers keep them talking. Top of mind means tip of tongue.==


---

### Emotion
*When we care, we share. So how can we craft messages and ideas that make people feel something? Naturally contagious content usually evokes some sort of emotion. Blending an iPhone is surprising. A potential tax hike is infuriating. Emotional things often get shared. So rather than harping on function, we need to focus on feelings. But as we'll discuss, some emotions increase sharing, while others actually decrease it. So we need to pick the right emotions to evoke. We need to kindle the fire. sometimes even negative emotions may be useful.*

**The Power of Awe**
- Scientific articles, innovations, and discoveries evoke emotion in readers.
- occurs when someone is inspired by great knowledge, beauty, sublimity, or might.
	- it is the experience of confronting *something greater than yourself*
- Awe is a complex emotion and frequently involves a sense of surprise, unexpectedness, or mystery.

> [!quote]
> 
>> "The most beautiful emotion we can experience is the mysterious. It is the power of all true art and science. He to whom this emotion is a stranger, who can no longer pause to wonder and stand rapt in awe, is as good as dead."
>>
>>\-Albert Einstein

Positive articles are more likely to be highly shared than negative ones. 

Recently psychologists have argued that emotions can also be classified based on activation, or physiological arousal.
- Think about the last time you gave a speech in front of a large audience
- Watching a scary movie or rollercoaster
- ==although your mind kept saying you weren't in any danger, your body is convinced otherwise==

>[!highlight]
>> Arousal is a state of activation and readiness for action. The heart beats faster and blood pressure rises. Evolutionarily, it comes from our ancestors' reptilian brains. Physiological arousal motivates a fight0or-flight response that helps organisms catch food or flee from predators

- Anger and anxiety, highly arousal, yell at others
- Anxiety, we constantly check and recheck things
- Excitement, we want to do something rather than to stay still
- *Awe, we can't help wanting to tell people what happened*

- An experiment ran at Whartons Behavioral Lab
	- Having people running in place to mimic the same physiological arousal response happening during emotions, faster heart rate, increase in blood pressure
	- Compared to participants who remained seated, there was a 75% increase in sharing of articles and information.
	- Arousal from emotional or physical sources or situation itself (rather than the content) all can boost transmission


---

### Public
*Can people see when others are using our product or engaging in our desired behavior? The famous phrase "Monkey see, monkey do" captures more than just the human tendency to imitate. It also tells us that it's hard to copy something you can't see. Making things more observable makes them easier to imitate, which makes them more likely to become popular. So we need to make our products and ideas more public. We need to design products and initiatives that advertise themselves and create a behavioral residue that sticks around even after people have bought the product or espoused the idea.*

> 	Jobs asked Ken Segall (Steve Job's right hand man, creative director at Job's ad agency)
> 	- what was more important?
> 		- The Apple logo on laptops, for it to look right to the customers before they opened their laptop (as a compass)
> 		- Or make it look right to the rest of the world when the laptop was in use?
> 	
> 	- The conclusion, flipping the logo
> 	- Observability. Seeing others do something make people more likely to do it themselves.

>[!tip] Public Visibility
> The easier it is for others to see, the easier for them to imitate.
> The key factor driving products to catch on is *public visibility*
> If something is built to show, it's built to **grow**

- When iPod first came out, they made the product stand out by making the headphones white
- Pringles distinctive tube
- Computers with MSFT OS boot up sound
- Louboutin thought his shows lacked energy, saw a Chanel employee's red nail polish, and painted his shoe soles red


The Psychology of Imitation

- People tend to conform to what others are doing
	- Television shows use canned laugh tracks for this reason: people are more likely to laugh when they hear others laughing
	- People who are waiting for a kidney transplant will turn down an available kidney if tons of others have rejected it. Simply because it seems like an inferior kidney.

- Hotmail first came about, a better product as a Web-based e-mail compared to AOL (monthly fee, dial-up from home)
- When emails were sent and received from Hotmail, on the bottom of the msg writes (Get Your Private, Free E-mail from Hotmail)
	- Apple and Blackberry adopted the same strategy
	- "Sent from my iPhone", "Sent using Blackberry"

>[!tip] Advertising without an Advertising Budget
>
>Designing products that advertise themselves is a particularly powerful strategy for small companies or organizations that don't have a lot of resources, existing customers can act as advertisements.

*Behavioral Residue*
- When something generates social proof that sticks around even when the product is not being used or the idea isn't top of mind.
- The physical traces or remnants taht most actions or behaviors leave in their wake

- Lululemon made shopping bags that are hard to throw away. So people use them to carry groceries or do other errands. This behavrioal residue helps provide social proof for the brand


---


### Practical Value
*How can we craft content that seems useful? People like to help others, so if we can show them how our products or ideas will save time, improve health, or save money, they'll spread the word. But given how inundated people are with information we need to make our message stand out. We need to understand what makes something seem like a particularly good ddeal We need to highlight the incredible value of what we offer---monetarily and otherwise. And we need to package our knowledge and expertise so that people can easily pass it on*

When talking about things that aren't particularly remarkable, Social Currency isn't playing much of a role. Instead, Practical Value is of importance, and gets people talking.
- People like to pass along practical, useful information. 
- People share practically valuable information to help others

> 	==If Social Currency is about information senders and how sharing makes them look, Practical Value is mostly about the information receiver. It's about saving people time or money, or helping them have good experiences.

>[!Quote] Prospect Theory
>Kaneman is a psychologist, not an economist. His work with Amos Tversky won a Nobel prize for what they called "prospect theory".
>
>The way people make decisions often violates standard economic assumptions about how they *should* make decisions. Judgements and decisions are not always rational or optimal. Instead they are based on psychological principles of how people perceive and process information

People don't value things in absolute terms, they evaluate them relative to a comparison standard, or "reference point"
- 50 cents for coffee isn't just fifty cents for coffee
- Whether that seems like a fair price or not depends on your expectations
- Living in New York VS From Rural India

>[!Quote] Diminishing Sensitivity
>
>Diminishing sensitivity reflects the idea that the same chane has a smaller impact the farther it is from the reference point.
>
>Driving 30 minutes to save $10 dollars on a $35 clock radio
>VS
>Driving 30 minutes to save $10 dollars on a $650 TV


Rule of 100,
Anything that costs less than 100, using a % discount is more appealing than $ discount
Anything that costs more than 100, useing a $ discount is more appealing than % discount


---

### Stories
*What broader narrative can we wrap our idea in? People don't just share information, they tell stories. But just like the epic tale of the Trojan Horse, stories are vessels that carry things such as morals and lessons. Information travels under the guise of what seems like idle chatter. So we need to build our own Trojan horses, embedding our products and ideas in stories that people want to tell. But we need to do more than just tell a great story. We need to make virality valuable. We need to make our message so integral to the narrative that people can't tell the story without it.*

**Stories are the original form of entertainment**
People tell stories for the same reasons they share word of mouth. Some narratives are about Social Currency.

>	==Just like the trojan Horse itself, stories are more than they seem.==
>	
>		The outward shell of a story, is the *surface plot*
>			Grabs your attention and engages your interest
>		Peel back the exterior, you'll find something hidden inside
>	Stories carry things, a lesson or moral.

Stories, can act as vessels, carriers that help transmit information to others.

Making Virality Valuable

Ron Bensimhon crashed the Athens Olympics and belly-flopped into the pool wearing "goldenpalace.com" as a slogan

Marketers consider this as one of the wors t guerrilla marketing failures because 
- it disrupted the competition
- ruined the moment for athletes
- Bensimhon got arrested and fined
- ==the stunt had nothing to do with the product it was trying to promote==
	- Everyone was talking about the story, but no one was talking about goldenpalace

Virality is most valuable when the brand or product benefit is *integral* to the story. When it's woven so deeply into the narrative that people can't tell the story without mentioning it.

---

### Epilogue

**STEPPS** | **Idiom**
--|--
Social Currency | We share things that make us look good
Triggers | Top of mind, Tip of tongue
Emotion | When we care, we share
Public | Built to show, built to grow
Practical Value | News you can use
Stories | Information travels under the guise of idle chatter



****