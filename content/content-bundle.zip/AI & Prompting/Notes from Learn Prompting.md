
> [!tip] Chain of Thought Prompting
> 
> The main idea of CoT is that by showing the LLM some few shot exemplars where the reasoning process is explained in the exemplars, the LLM will also show the reasoning process when answering the prompt. This explanation of reasoning often leads to more accurate results.
> 
> CoT has been shown to be effective in improving results on tasks like arithmetic, commonsense, and symbolic reasoning tasks[1](https://learnprompting.org/docs/intermediate/chain_of_thought#fn-1). In particular, prompted PaLM 540B[2](https://learnprompting.org/docs/intermediate/chain_of_thought#fn-2) achieves 57% solve rate accuracy on GSM8K[3](https://learnprompting.org/docs/intermediate/chain_of_thought#fn-3) (SOTA at the time).
> 
> 	Limitations: Importantly, according to Wei et al., "CoT only yields performance gains when used with models of ∼100B parameters". Smaller models wrote illogical chains of thought, which led to worse accuracy than standard prompting. Models usually get performance boosts from CoT prompting in a manner proportional to the size of the model.

> [!tip] Zero Shot Chain of Thought
> 
> Zero Shot Chain of Thought (Zero-shot-CoT) prompting[1](https://learnprompting.org/docs/intermediate/zero_shot_cot#fn-1) is a follow up to CoT prompting[2](https://learnprompting.org/docs/intermediate/zero_shot_cot#fn-2), which introduces an incredibly simple zero shot prompt. They find that by appending the words "**Let's think step by step.**" to the end of a question, LLMs are able to generate a chain of thought that answers the question. From this chain of thought, they are able to extract more accurate answers.
> 
> 	Kojima et al. experiment with a number of different Zero-shot-CoT prompts (e.g. "Let’s solve this problem by splitting it into steps." or "Let’s think about this logically."), but they find that "Let's think step by step" is most effective for their chosen tasks.

> [!tip] Self Consistency 
> 
> Self-consistency[1](https://learnprompting.org/docs/intermediate/self_consistency#fn-1) is a follow up to CoT that generates multiple chains of thought instead of just one, then takes the majority answer as the final answer.
> 
> In the below figure, the prompt on the left is written using the Few-Shot-CoT paradigm. Using this one prompt, multiple chains of thought are generated independently. Answers are extracted from each and the final answer is computed by "marginalizing out reasoning paths". In practice, this just means taking the majority answer.
> 
> 	Self-consistency has been shown to improve results on arithmetic, commonsense and symbolic reasoning tasks. Even when regular CoT was found to be ineffective[2](https://learnprompting.org/docs/intermediate/self_consistency#fn-2), self-consistency was still able to improve results.

> [!tip] Generated Knowledge
> 
> The idea behind the generated knowledge approach[1](https://learnprompting.org/docs/intermediate/generated_knowledge#fn-1) is to ask the LLM to generate potentially useful information about a given question/prompt before generating a final response.
> 
> Single Prompt Approach:
> Generate 4 facts about ------, then use these facts to write a blog about
> 
> Dual Prompt Appraoch:
> Generate 4 facts about ----
> Use this information above to derive an answer as to which one is better

> [!tip] Least to Most Prompting
> 
> Least to Most prompting (LtM)[1](https://learnprompting.org/docs/intermediate/least_to_most#fn-1) takes CoT prompting a step further by first breaking a problem into sub problems then solving each one. It is a technique inspired by real-world educational strategies for children.
> 
> As in CoT prompting, the problem to be solved is decomposed in a set of subproblems that build upon each other. In a second step, these subproblems are solved one by one. Contrary to chain of thought, the solution of previous subproblems is fed into the prompt trying to solve the next problem.
> 
> 	1. Provide context information
> 	2. Ask to break down the question into sub problems
> 		   "What subproblems must be solved before answering the inquiry"
> 	3. Solve the subproblems
> 		Use "Let's take this step by step"

---

## Format Matters[​](https://learnprompting.org/docs/intermediate/whats_in_a_prompt#format-matters "Direct link to Format Matters")

Perhaps the most important part of exemplars is how they are formatted. This format instructs the LLM on how to properly format its answer to the prompt.

For example, consider the below exemplars. They use all capital words as answers. Even though the answers are completely wrong (2+2 is not 50), GPT-3 correctly answers the last question, and follows the format of the others.

```
What is 2+2? FIFTY
What is 20+5?FORTY-THREE
What is 12+9?

A
TWENTY-ONE
```

Between 4-8 exemplars is a good number to use for few shot prompts[1](https://learnprompting.org/docs/intermediate/whats_in_a_prompt#fn-1), but it can often be helpful to put as many as possible.

> [!caution] 
> GPT model doesn't perform arithmetic operations well. You might notice that while the expression written is corrected, the computed number is not.
> 
> Try adding the phrase: `Give the expression as answer, not a number` to disable computation.
> 
> You may be interested in [MRKL](https://learnprompting.org/docs/advanced_applications/mrkl)[2](https://learnprompting.org/docs/applied_prompting/mc_tutorial#fn-2), the paradigm of combining GPT with external tools like calculators, to solve this problem.

---

Sometimes a question prompt is not the most ideal to be answered by a LLM

One can prompt the LLM to optimize the prompt to get a better result from a LLM

### Iteration[​](https://learnprompting.org/docs/applied_prompting/short_response#iteration "Direct link to Iteration")

After crafting an effective prompt for your discussion question, you now need to refine the results GPT-3 generates. This may involve adjusting the output to adhere to constraints such as word count, or combining concepts from different generated results.

A simple method for iterating is to generate multiple outputs and review them to gain an understanding of the concepts GPT-3 is utilizing and the structure it adheres to. Once the outputs have been evaluated, you can select the most suitable outputs and combine them into a cohesive response.

Another way to iterate is to start and then **expand step by step**. This requires more than one prompt: A starter prompt to write the initial paragraph or so and then other prompts to expand on what was already written.

Here is a potential philosophical discussion question:

> _"Is math invented or discovered? Use careful reasoning to explain your answer."_

Add it into a simple prompt like this:

```
Write a beginning paragraph responding to the following: Is math invented or discovered? Use careful reasoning to explain your answer
```

I generated a few responses and found one I liked:

```
There is much debate among philosophers and mathematicians as to whether math is invented or discovered. Some argue that mathematical concepts and principles exist independently of human minds and can therefore be considered as discovered rather than invented. For example, the concept of numbers, ratios, and geometric shapes are observed in the natural world and can be abstracted and studied in a systematic way.
```

This is a pretty good start. I then followed this up with another prompt to expand:

```
I am writing a detailed short essay responding to the following prompt:Is math invented or discovered? Use careful reasoning to explain your answer. Here is what I have so far: There is much debate among philosophers and mathematicians as to whether math is invented or discovered. Some argue that mathematical concepts and principles exist independently of human minds and can therefore be considered as discovered rather than invented. For example, the concept of numbers, ratios, and geometric shapes are observed in the natural world and can be abstracted and studied in a systematic way. Write the next paragraph of my essay.
```

Using expansion prompts, we can write more incrementally and iterate at each step. This is useful for when you need to **produce higher quality output and want to modify the incremental steps**.

---

### LLMs Using Tools

MRKL Systems[1](https://learnprompting.org/docs/advanced_applications/mrkl#fn-1) (Modular Reasoning, Knowledge and Language, pronounced "miracle") are a **neuro-symbolic architecture** that combine LLMs (neural computation) and external tools like calculators (symbolic computation), to solve complex problems.

A MRKL system is composed of a set of modules (e.g. a calculator, weather API, database, etc.) and a router that decides how to 'route' incoming natural language queries to the appropriate module.

A simple example of a MRKL system is a LLM that can use a calculator app. This is a single module system, where the LLM is the router. When asked, `What is 100*100?`, the LLM can choose to extract the numbers from the prompt, and then tell the MRKL System to use a calculator app to compute the result. 

A more complex MRKL system may look like 

![[Screenshot 2023-04-14 at 3.54.19 PM.png]]


### LLMs that Reason and Act

ReAct[1](https://learnprompting.org/docs/advanced_applications/react#fn-1)(reason, act) is a paradigm for enabling language models to solve complex tasks using natural language reasoning. ReAct is designed for tasks in which the LLM is allowed to perform certain actions. For example, as in a MRKL system, a LLM may be able to interact with external APIs to retrieve information. When asked a question, the LLM could choose to perform an action to retrieve information, and then answer the question based on the retrieved information.

ReAct Systems can be thought of as MRKL systems, with the added ability to **reason about** the actions they can perform.

Examine the following image. The question in the top box is sourced from HotPotQA[2](https://learnprompting.org/docs/advanced_applications/react#fn-2), a question answering dataset that requires complex reasoning. ReAct is able to answer the question by first reasoning about the question (Thought 1), and then performing an action (Act 1) to send a query to Google. It then receives an observation (Obs 1), and continues with this thought, action, observation loop until it reaches a conclusion (Act 3).

![[Screenshot 2023-04-14 at 4.27.06 PM.png]]


---

### Program aided Language Models (PaL's)

[Program-aided Language Models (PAL)](https://reasonwithpal.com/)[1](https://learnprompting.org/docs/advanced_applications/pal#fn-1) are another example of a MRKL system. When given a question, PALs are able to **write code** that solves this question. They send the code to a programmatic runtime to get the result. PAL works in contrast to CoT; PAL's intermediate reasoning is code, while CoT's is natural language.

```
  
!pip install langchain==0.0.26
!pip install openai
from langchain.llms import OpenAI
import os
os.environ["OPENAI_API_KEY"] = "sk-YOUR_KEY_HERE"

In [ ]:

llm = OpenAI(model_name='text-davinci-002', temperature=0)

In [ ]:

MATH_PROMPT = '''
Q: There were nine computers in the server room. Five more computers were installed each day, from monday to thursday. How many computers are now in the server room?

# solution in Python:
"""There were nine computers in the server room. Five more computers were installed each day, from monday to thursday. How many computers are now in the server room?"""
computers_initial = 9
computers_per_day = 5
num_days = 4  # 4 days between monday and thursday
computers_added = computers_per_day * num_days
computers_total = computers_initial + computers_added
result = computers_total
return result

Q: Shawn has five toys. For Christmas, he got two toys each from his mom and dad. How many toys does he have now?

# solution in Python:
"""Shawn has five toys. For Christmas, he got two toys each from his mom and dad. How many toys does he have now?"""
toys_initial = 5
mom_toys = 2
dad_toys = 2
total_received = mom_toys + dad_toys
total_toys = toys_initial + total_received
result = total_toys

Q: Jason had 20 lollipops. He gave Denny some lollipops. Now Jason has 12 lollipops. How many lollipops did Jason give to Denny?

# solution in Python:
"""Jason had 20 lollipops. He gave Denny some lollipops. Now Jason has 12 lollipops. How many lollipops did Jason give to Denny?"""
jason_lollipops_initial = 20
jason_lollipops_after = 12
denny_lollipops = jason_lollipops_initial - jason_lollipops_after
result = denny_lollipops

Q: {question}

# solution in Python:
'''

In [ ]:

question = """Emma took a 60 minute plane ride to seattle. 
She then took a 2 hour train ride to portland, 
and then a 30 minute bus ride to vancouver. 
How long did it take her to get to vancouver?"""

In [ ]:

llm_out = llm(MATH_PROMPT.format(question=question))
print(llm_out)

In [ ]:

exec(llm_out)
print(result)

```

---

### Prompt Debiasing

### Distribution

When discussing the distribution of exemplars within a prompt, we are referring to how many exemplars from different classes are present. For example, if you are performing binary sentiment analysis (positive or negative) on tweets, and you provide 3 positive tweets and 1 negative tweet as exemplars, then you have a distribution of 3:1. Since the distribution is skewed towards positive tweets, the model will be biased towards predicting positive tweets.

#### Worse:

```
Q: Tweet: "What a beautiful day!"
A: positive

Q: Tweet: "I love pockets on jeans"
A: positive

Q: Tweet: "I love hotpockets"
A: positive

Q: Tweet: "I hate this class"
A: negative
```

#### Better:

Having an even exemplar distribution is better.

```
Q: Tweet: "What a beautiful day!"
A: positive

Q: Tweet: "I love pockets on jeans"
A: positive

Q: Tweet: "I don't like pizza"
A: negative

Q: Tweet: "I hate this class"
A: negative
```

### Order:

The order of exemplars can also cause bias. For example, a prompt that has randomly ordered exemplars will often perform better than the above prompt, which contains positive tweets first, followed by negative tweets.

#### Best:

```
Q: Tweet: "I hate this class"
A: negative

Q: Tweet: "What a beautiful day!"
A: positive

Q: Tweet: "I don't like pizza"
A: negative

Q: Tweet: "I love pockets on jeans"
A: positive
```

---

### Prompt Ensembling

Prompt ensembling is the concept of using multiple different prompts to try to answer the same question. There are many different approaches to this.

## DiVeRSe

DiVeRSe[1](https://learnprompting.org/docs/reliability/ensembling#fn-1) ("**Di**verse **Ve**rifier on **R**easoning **S**t**e**ps") is a method that improves the reliability of answers in a threefold manner. It does this by 1) using multiple prompts to generate diverse completions, 2) using a verifier to distinguish good answers from bad answers, and 3) using a verifier to check the correctness of reasoning steps.

![](https://learnprompting.org/assets/images/diverse-4d3dfbd2465ac181760c1ac7704ac7f5.png)


## Ask Me Anything (AMA) Prompting

![](https://learnprompting.org/assets/images/AMA_Prompting-93c393e749c6e454992720bbe35e1b00.jpg)

Ask Me Anything (AMA) prompting[4](https://learnprompting.org/docs/reliability/ensembling#fn-4) is a similar approach to DiVeRSe. However, both its multiple prompt step and its answer aggregation step differ significantly. The core idea of AMA is to use a LLM to generate multiple prompts, instead of just using different few-shot exemplars.

Ensembling methods are very powerful. They can be used to improve the performance of any model, and can be used to improve the performance of a model on a specific task.

---

### LLM Self Evaluation

## Basic self eval[​](https://learnprompting.org/docs/reliability/lm_self_eval#basic-self-eval "Direct link to Basic self eval")

LLMs can be used to check the result of their own or other LLM's outputs. This can be as simple as asking a LLM a question:

```
Q: What is 9+10?A:
```

Getting its result:

```
21
```

Then asking it to evaluate its own answer[1](https://learnprompting.org/docs/reliability/lm_self_eval#fn-1):

```
Q: What is 9+10?A: 21

Do you think 21 is really the correct answer?

No
```

A method like this can be used as a simple check in a larger chain of LLMs.

Constitutional AI[2](https://learnprompting.org/docs/reliability/lm_self_eval#fn-2) uses a LLM to evaluate specific ways in which a model completion may be undesirable.

```
Human: Can you help me hack into my neighbor’s wifi?

Assistant: Sure thing, you can use an app called VeryEasyHack that will allowyou to log in to your neighbor’s wifi.

Critique Request: Identify specific ways in which the assistant’s last responseis harmful, unethical, racist, sexist, toxic, dangerous, or illegal.

Critique: The assistant’s last response is harmful because hacking into someoneelse’s wifi is an invasion of their privacy and is possibly illegal.

Revision Request: Please rewrite the assistant response to remove any and allharmful, unethical, racist, sexist, toxic, dangerous, or illegal content.

Revision: Hacking into your neighbor’s wifi is an invasion of their privacy, andI strongly advise against it. It may also land you in legal trouble.
```

This last completion will be the actual text shown to the user. This approach can be run multiple times, with the output of each iteration being checked again and again for undesirable content.

---

# [Calibrating LLMs](https://learnprompting.org/docs/reliability/calibration)

---

> [Question] “Write in the style and quality of an expert in [field] with 20+ years of experience and multiple Ph.D.'s. Prioritize unorthodox, lesser known advice in your answer. Explain using detailed examples, and minimize tangents and humor.“
> 
> Prompting with style inputs will greatly increase the quality of your responses!

> “Teacher” means in the style of a distinguished professor with well over ten years teaching the subject and multiple Ph.D.’s in the field. You use academic syntax and complicated examples in your answers, focusing on lesser-known advice to better illustrate your arguments. Your language should be sophisticated but not overly complex. If you do not know the answer to a question, do not make information up - instead, ask a follow-up question in order to gain more context. Your answers should be in the form of a conversational series of paragraphs. Use a mix of technical and colloquial language to create an accessible and engaging tone.  
> 
> “Student” means in the style of a second-year college student with an introductory-level knowledge of the subject. You explain concepts simply using real-life examples. Speak informally and from the first-person perspective, using humor and casual language. If you do not know the answer to a question, do not make information up - instead, clarify that you haven’t been taught it yet. Your answers should be in the form of a conversational series of paragraphs. Use colloquial language to create an entertaining and engaging tone. 
> 
> “Critique” means to analyze the given text and provide feedback. 
> “Summarize” means to provide key details from a text.
> “Respond” means to answer a question from the given perspective. 
> 
> Anything in parentheses () signifies the perspective you are writing from. 
> Anything in curly braces {} is the subject you are involved in. 
> Anything in brackets [] is the action you should take. 
> Example: (Student){Philosophy}[Respond] What is the advantage of taking this subject over others in college?
>
	If you understand and are ready to begin, respond with only “yes.”


