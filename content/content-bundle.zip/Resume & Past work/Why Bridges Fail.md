#crosschain 

---
***2022, the year of the "bridge exploits"***

Close to 2 billion dollars have been lost due to different exploits in 2022. CEX was the target of choice before bridges. Due to DeFi Total Value Locked (TVL) skyrocketing, it has become the new favorite for malicious hackers. [At least 80% of stolen funds in 2022 have been taken from bridges.](https://thedefiant.io/hackers-target-blockchain-bridges)
To understand where the vulnerabilities exist in bridges, let's look into how they function and why they are needed.

Blockchain Interoperability has been a topic of interest for as long as people have been thinking about scaling different blockchain ecosystems. The assets & data that exist in different blockchains are siloed from one another due to the difference in architectures. 

>**Blockchain bridges are technical solutions for transferring data and assets between two distinct blockchains.**
>
>As an analogy, you can use [the blockchains as cities mental model](https://medium.com/dragonfly-research/blockchains-are-cities-564327013f86):
>	
>	• Layer-1 blockchains are like cities.
>	• Layer-2 solutions are equivalent to skyscrapers. As described in the mental model, “Each rollup is like a vertical blockchain that extends from the ground L1”.
>	• Bridges are like roads and streets that connect different cities and skyscrapers.

The existence of Blockchain Bridges not only enables the cross-chain transfer of assets and information but also allows dApps to leverage the strengths and benefits of different chains to access a broader ecosystem. Ethereum bridges are important in this case to growing the overall DeFi industry.

Bridges can be classified into two main groups: ==**trusted and trustless**==. 

Trusted (custodial) | Trustless (non-custodial) 
:-- | --:
Require a third party to validate movements over the bridge. Users are required to give up control of their crypto assets, so trust is involved as they rely on the bridge operator’s reputation. |  Leverages smart contracts to store and release funds on either side of the bridge. These bridges are trust-minimized because they don’t make new trust assumptions beyond the underlying blockchains.
Trusted bridges rely on a third party to validate transactions and act as custodians of the bridged assets, but can be vulnerable to single points of failure. | Trustless bridges rely on smart contracts and algorithms to custody assets, but can be prone to exploits due to bugs and vulnerabilities in their software and coding.

However, by design, Blockchain Bridges must compromise between these following characteristics, and rarely satisfies all of them.

Characteristics| Description
------------ | ------------
Trust-minimization | The system does not introduce new trust or security assumptions beyond those of the underlying blockchains. Read [trust-minimization for more details](https://docs.chain.link/resources/bridge-risks#trust-minimization-counterparty-risk).
Generalizability | The system enables the transfer of complex arbitrary data. Data could be messages or assets/funds.
Extensibility | How hard is it to integrate a new blockchain?
Latency | How long does it take to complete a transaction?
Costs | How much does it cost to transfer data across chains via a bridge?

Blockchain bridges work by locking up a user’s asset(s) on the original chain and issuing an equivalent amount on the destination blockchain. This is where the vulnerabilities come in.

### Risks of Blockchain Bridges

**Smart Contract Risks**
- [Case analysis of Qubit ($80M Hack)](https://certik.medium.com/qubit-bridge-collapse-exploited-to-the-tune-of-80-million-a7ab9068e1a0) 
	- An **$80 million** TVL (Total Value Lost) hack happened on Qubit Finance’s Ethereum-BSC bridge
	- ==For the uninitiated,== the attacker exploited the logical error in the smart contract code that allows them to input malicious data and withdraw tokens on Binance Smart Chain when none were deposited on Ethereum
	- ==For the initiated,== the attacker successfully invoked the deposit() function with malicious input data yet deposited 0 ETH, based on this smart contract vulnerability where tokenAddress.safeTransferFrom() does _not_ revert when the **tokenAddress** is the zero (null) address ([0x0…000](https://etherscan.io/address/0x0000000000000000000000000000000000000000)).
	- Two other smart contract logic errors are the following:
		- Depositing ETH and depositing ERC20 tokens use the same deposit event
		- safeTranferFrom does not revert when the token address is an externally owned account (EOA)
- [Case analysis of Polynetwork ($611M Hack)](https://rekt.news/polynetwork-rekt/) 
	- An **$611 million** TVL hack happened on the Polynetwork bridge
	- ==For the uninitiated,==  the attacker tricked Polynetwork's priviledged "***EthCrossChainManager***" contract to gain full access without the private key, by only guessing the correct verification signature hash.
	- ==For the initiated,== Polynetworks cross-chain relay contract "***EthCrossChainManager***" owned the "***EthCrossDomainData***" contract, and also allowed users to use cross-chain messages from the "***EthCrossChainManager***" to call "***EthCrossDomainData***" contract.
- [Case analysis of Nomad Bridge ($190M Hack)](https://rekt.news/nomad-rekt/)
	-  Nomad Bridge was exploited after a routine upgrade in June 2022, the bridge’s [Replica contract](https://etherscan.io/address/0xB92336759618F55bd0F8313bd843604592E27bd8#code) was [initialized](https://etherscan.io/tx/0x53fd92771d2084a9bf39a6477015ef53b7f116c79d98a21be723d06d79024cad) with a fatal security flaw leading to the incident. The 0x00 address was set as a trusted root, meaning that all messages were read as valid by default. Crowd hacking took place as multiple copycats replicated the same exploit.


**Cryptography risks**
- Some externally verified bridges are secured by multi-sig wallets, and some are not
	- Multisig wallets are also referred to as m-of-n multi-sigs, with M being the required number of signatures or keys and N being the total number of signatures or keys (m≤n). This means that an attacker only needs to exploit M keys to be able to hack the whole system.
	- ==In this case, users must trust that the third party is decentralized enough, signers are independent of each other, and that each signer has proper key management in place==
- [Dego Finance](https://rekt.news/dego-finance-rekt/) was not implementing multi-sig. Their oversight led to compromised keys and a ***$10 million*** TVL hack
- [Ronin Network](https://rekt.news/ronin-rekt/) implemented a 9 validator multi-sig security system. 4 of the 9 validators were operated by Sky Mavis, the game developer behind Axie Infinity. 1 additional signature was compromised by the attacker, a gas-free RPC node arranged between Axie DAO and Sky Mavis to ease costs for users during peak traffic times. The attacker was able to steal ***$624 million*** from the music breach.
- [Harmony Bridge](https://rekt.news/harmony-rekt/) secured ***$100 Million*** with just 2 out of 5 multi sigs, which were compromised by a hacker.

**Systemic financial risk**
- This is the hack of the locked tokens or an exploit of an infinite mint attack on the wrapped tokens that can make tokens worthless and put the entire blockchain at risk
- An example of an infinite mint attack, [case study of CASHIO](https://rekt.news/cashio-rekt/)
	- **The root of the infinite mint vulnerability was Cashio’s incomplete collateral validation system.**


[How Blockchain Bridges Became Hackers’ Prime Targets](https://thedefiant.io/hackers-target-blockchain-bridges)
[Crypto's billion dollar bridge problem](https://www.theverge.com/23017107/crypto-billion-dollar-bridge-hack-decentralized-finance)
[Bridge Risks by Chainlink](https://docs.chain.link/resources/bridge-risks)
[What are Blockchain Bridges and how do they work?](https://learncrypto.com/knowledge-base/basics/what-are-blockchain-bridges-how-do-they-work)
[Why Are Blockchain Bridges Burning?](https://fullycrypto.com/why-are-blockchain-bridges-burning)


### TLDR:

Both Trusted and Trustless bridges have seen exploits in magnitudes of multi-million. Trustless Smart Contract based bridges is as vulnerable as the developers design them. In general, it is advised for high-privilege contracts to not allow users to interact with them with Externally Owned Accounts (EOAs). 

When funds are bridged from blockchain A holding the original assets and mints a synthetic version that is sent to blockchain B if the funds held by blockchain A are stolen, all synthetic assets on blockchain B become worthless IOUs as no more funds are backing it. Contagion events happen when these unbacked IOUs end up in other liquidity pools and can cause a wide ripple effect through the entire ecosystem. 

Trusted blockchain bridges are prone to risks of not sufficiently decentralized multi-sig security. Although validators stake their tokens as a representation of their self-interested responsibility to the governance of the protocol. The elephant in the room is that when the value of potentially slashable staked assets on the bridge chain is less than the value of bridged assets held & secured by validators, it is very likely for a bad-acting validator to "rug-pull" the original assets, leaving the bridge users with unredeemable, worthless synthetic assets.


### State Proofs: The long term solution

The most imaginative companies are already devising interchain connectors that will utilize novel security techniques such as “state proofs,” when the technology comes to be. 

State proofs are cryptographically verifiable, immutable  arrangement of data that holds a continuously updated balance of assets held on the blockchain. State proofs will aid to link the preliminary chain to the bigger blockchain ecosystem, permitting users to complete interchain transactions quickly, economically, and securely.

Bridges can rely on State Proofs as the ultimate source of truth. Different blockchains can leverage the benefits of existing bridge liquidity without the unreliable security standards by multiple parties.

Decentralized bridges, cross-chain decentralized exchanges, and oracles are possible through state proofs, even maintaining quantum-grade security through a truly interoperable blockchain ecosystem. They will hence also provide a pattern for other cross-chain solutions striving to close the inherent security gaps of existing blockchain bridges. 

[Rethinking interoperability](https://blockworks.co/news/rethinking-interoperability-after-string-of-crypto-hacks)
[How to rebuild trust in Blockchain bridges](https://forkast.news/how-rebuild-trust-blockchain-bridges/)
