`Enyu Rao et al.`

### Executive Summary:

The following is an analytics report for StumbleUpon, a user-curated web content discovery engine that recommends high-quality relevant pages based on interests. The project’s goal is to evaluate a large set of URLs and build models that aim to use the most relevant variables in determining whether the URL is evergreen, signifying timeless relevance, or ephemeral, signifying that content was relevant for a short period of time.

After our StumbleUpon data set in Tableau and getting a better understanding of the nature of our variables, we created two models to determine which is most accurate at predicting the timeliness of the URLs. In our third and final phase, we will be properly cleaning our dataset and building models to test against each other in hopes of obtaining a model that most accurately predicts our target. Now, we will be digging through the original dataset and tweaking what we believe will most effectively and efficiently bring our model’s error rate down. We acknowledge that this data has multiple data issues as it is a very large dataset. With respect to the scarcity of time, we decided it was best to focus on one aspect of the dataset, which solved previous problems and provided new insights.

This ultimately offered us insight into which words were most frequently used in ephemeral/evergreen content. Some words that turned out to be most important were recipe(s), chocolate, butter, and others (more on that later in the report). After cleaning, we built our third model, along with the two other previously constructed models, and found our error rate to have decreased significantly. We then constructed a bagging and a stacking model, and compared these to the other models in order to provide our client with our best recommendation.
  
### Data Cleaning:

Previously, we cleaned our data by replacing missing values that showed up as ‘?’ and ‘NA’ with 0 for the sake of simplicity and to move forward with building our model. Now, we looked through the dataset, searching each column to identify any issues that would have affected our data and adjusted accordingly.

There were methods of data cleaning that were maintained from Phase 2 of this project including going column by column to decide which variables were worth keeping. Many of them needed to be reformatted to benefit our models. We found that there was an abundance of missing values within the dataset either classified as“NA” or “?”; this may be due to the fact that the person who prepared this dataset did not have sufficient information about these articles to conclude their category. Some variables merely had “0”, “1” or “?” as inputs within their column set. Subsequently, these columns were managed and set as factor variables due to their categorical properties. While variables such as “alchemy_category_score” were labeled as numerical variables within R, this classification was  implemented because R by itself cannot determine the variables categories from the raw dataset collected by StumbleUpon.

Additionally, we decided to set variable “url” and “urlid” as NULL to disregard them when constructing models since each article had its own id/url name. However, we hesitated to proceed with removing the variable “boilerplate” because we believe there was valuable information within the boilerplate texts that could help us further determine an article’s odds of being Evergreen. The ‘Bag of Word’ method was perfect for this task, as “boilerplate” was the text description of the individual articles. We first separated words from the sentence/phrase format of the boilerplate text. Of course, with 5000 unique article descriptions, the total amount of words repeatedly used came in large at a word count of nearly 2,355,000. Of these 2,355,000 words used, there remained those that were too commonly used in the English language, which would not be beneficial in identifying whether or not an article was evergreen or ephemeral as they were simply neutral.

We then proceeded to remove these commonly used words such as “they” “that” and “the”, subsequently cutting down the word count down by almost half to 1,215,000. We then realized we couldn’t stop there as there are words used so infrequently they become irrelevant. By setting a parameter of 500, we were able to cut down the word count list to 329 words that are used more than 500 times in all of the boilerplate texts - a significant improvement. With this final step, we were left with 329 words that were highly used in articles, appearing thousands of times, allowing us to identify the top 5 words that appeared the most in Ephemeral and Evergreen web pages respectively. These 5 words are as follows:


Top 5 words for **Evergreen** | Odds article containing keyword will be Evergreen
--|--
**recipe** | 44,590,000 to 1
**chocolate**  | 32,820,000 to 1
**minutes** |31,040,000 to 1
**butter** | 29,270,000 to 1
**recipes** |28,860,000 to 1

Top 5 words for **Ephemeral** |Odds article containing keyword will be Ephemeral
--|--
**fashion** | 13,620,000 to 1
**news** |13,320,000 to 1
**sports** | 13,170,000 to 1
**video** | 10,030,000 to 1
**technology** |8,480,000 to 1

The strength of this approach is the ability to decipher a specific column of the dataset that initially seemed useless, and use it to better predict our target. One trade-off with this strategy, however, is that we were not able to address the rest of the issues existing in “?” and “NA” forms in the dataset. If this were to be addressed, we would have improved our model error rate even further. Yet, due to the amount of data issues and limited time, we decided to focus on one aspect, which we believed was the best approach to fulfilling this issue.

Revisiting our two models from Phase 2 with a clean dataset yielded great results in decreased error rates (see table below).

  

Models | Error rate **before** cleaning (phase 2) | Error rate **after** cleaning |% change
--|--|--|--
Logistic Ression |33.95% |24.3% |(28.42%)
Classification Tree|33.8% |23.35% |(30.92%)


Overall, the error rates on clean data were improvements compared to the error rates prior to data cleaning, as expected.

### Model Building:

After cleaning the dataset and rebuilding our previous models (results above) we constructed an additional model: the neural nets model. In the context of StumbleUpon, a false positive error is the first to be avoided as it misdirects subscribers to evergreen URLs although they are not. Meaning, the articles they mark as evergreen become irrelevant for the subscribers. As with the two other models, we aim to see if neural nets will perform better by yielding a lower error rate and maximizing specificity (yielding lower false positives). The neural net model performed at an error rate of 23.3%, whereas the error_bench was at a staggering 48.35%, a strong indicator on how it is better to use the neural net model than no model at all.

For our neural nets model, we made sure our data was managed appropriately with no variable with multiple factors levels. We ensured this was implemented because if not, our model would be unintelligible and would easily be overfit - which occurs when the model captures the noise of the data. In other words: when there are too many parameters. An example of overfitting is putting too many parameters on a model, leading the result to have many categories with little accuracy because there are not enough data points to accurately ‘back it up.’ We avoid it because it may inaccurately predict or reflect the data. 

Moving right along: it is fundamental that the inputs are normalized for this model. By doing so, every number is placed within a range and everything else is scaled accordingly. This results in the lowest value becoming ‘0’ and the highest becoming ‘1’ allowing everything else to fall in between. We were then able to build our model, plot, and make appropriate predictions and observations to find the associated error rate.

The neural nets model provided us with the lowest error rate of 23.3% compared to our other two models logistic regression (23.75%)  and classification trees (23.35%). This means that it is slightly better to use the neural nets model in comparison to the logistic regression and classification tree. 

The sensitivity rate states there is roughly a 71% chance we correctly predict the article is evergreen. This makes the false negative rate to be about 29% - which is the probability we predict the article isn’t evergreen even though it is. The specificity rate states there is roughly a 83% chance we correctly predict the article is non-evergreen. The false positive rate is therefore roughly about 17% - which is the probability we predict evergreen even though it isn’t. The false positive rate for the logistic regression is about 19% while it is roughly 20% for classification trees, meaning the false positive rate for the neural net model is lower than both logistic regression and classification trees.

The neural net model is better at correctly identifying ephemeral content as it has a lower false positive rate, which would serve as beneficial to StumbleUpon in minimizing the amount of errors. False positive rates will do more harm than false negative rates in the case of StumbleUpon because false positive rates are the chances that they wrongly identify articles as evergreen, when it is supposed to be ephemeral. This would be more harmful, as readers think that the articles are relevant when they are actually not. 

An issue with neural nets is that despite its lower error rate and overall better performance, we have no way of interpreting this model. When plotting the neural net, it is nearly impossible to anticipate our target just by looking at the net, as displayed below. Although it is not an easy model to explain, it is widely used and the performance is really good. It is important to acknowledge that we are using this model in conjunction with the two other models which are deemed easier to explain. This allows for further insights and support opposed to solely using the neural nets model, which would be much more difficult to use on its own.

  
**Plot of Neural Net Model:**
![[StumbleUpon Analytics.png]]

  
### Ensemble Learning:

After we completed our neural net model, we created bagging and stacking models in hopes of further enhancing our performance by lowering error rates. 

In our bagging model, we used a random forest model using 500 different training-test partitions (“trees”) in order to better predict whether or not an article is evergreen. Our bagging model averages out the 500 models, which helps reduce variance in our data and prevents overfitting. The variance gets reduced because the overfitted models become averaged out. 

In our stacking model, we utilized the outputs of our three base models — logistic regression, classification tree, and neural net —  and fed those outputs as well as the original inputs as inputs into our manager model, which is another logistic regression model. This allows the manager model to learn when to use each base model for the best result.  

We ran the model once again to reinforce our findings. It is important to consider that results will differ each time due to varying partition splits. When doing so, our bagging and stacking models still have the lowest error rates compared to our best constituent model, neural nets. These are the new performance metrics:

  

  
|  | Best Base Model: Nnet |Bagging |Stacking|
|--| --|--|--|
|Error Rate | 0.2335 |0.22 |0.2315|
| Specificity |830/(830+162) = .837 |863/(863+129) = .870 |829/(829+163) = .836
|False Positive |162/(830+162) = .163 |129/(863+129) = .130  |163/(829+163) = .164
|Sensitivity |703/(703+305) = .697 |697/(697+311) = .691 |708/(708+300) = .702
|False Negative |305/(703+305) = .303|311/(697+311) = .309 |300/(708+300) = .298

Looking at these numbers, it is easily seen that the best base model does not rival the two ensemble models. 

Our bagging model has a specificity rate of 87%, while our neural net model is only at 83.7%. This means that our bagging model is better than our neural net model at predicting when an article is going to remain ephemeral.

The neural net model also has a false positive rate of 16.3%, while our bagging model only has a rate of 13%. This means that the neural net model — compared to our bagging model —  is more likely to wrongfully predict an article as evergreen even though it is in fact ephemeral. 

On the other hand, our stacking model’s sensitivity rate is 70.2% compared to neural net’s 69.7%. This makes our stacking model better than our neural net model at predicting when an article will remain evergreen. 

The neural net model’s false negative rate is once again higher at a rate of 30.3% compared to our stacking model’s rate of 29.8%. Compared to our stacking model, our neural net model is more likely to incorrectly predict an article as ephemeral when it is actually evergreen. 

One might expect for the stacking model to perform better than the bagging model because stacking runs/trains a manager model on helper models. This means that stacking could have a leg up because it can utilize different models simultaneously, unlike bagging where it is likely the same model type over again (in the case of multiple trees). The added value by stacking is then that we are combining not just the helper model outputs (all the predictions for individual helper models), but also the original inputs so that the manager model can learn under what conditions various models are good/bad. 

However, based on our model errors, stacking (which performed worse than bagging) offers a lower error rate than our most successful ‘individual’ model, neural nets.When deciding between the use of our stacking or boosting model, it would really depend on StumbleUpon’s desired outlook of an article. If StumbleUpon is trying to predict an article as evergreen, they should stick with the stacking model, as it is better in identifying evergreen content, exemplified by the higher sensitivity rate (70.2% compared to 69.1%). However, if StumbleUpon is trying to predict an article as ephemeral, they should use our boosting model as it is better for the purpose of correctly identifying ephemeral content (specificity rate of 87% vs 83.6%). 

  
### Bag of words Code:

```
library(readr)

library(ggplot2)

library(tidyverse)

library(tidytext)

  

df = read_csv("C:/Users/erao1/Desktop/RStudio Data/stumbleupon.csv")

df_text = df[ , c("label", "boilerplate")]

df_text = df_text %>% unique()

df_text = df_text %>% mutate(ID = c(1:nrow(df_text)))

  

outcome = df_text %>% select(ID, boilerplate)

  

counts = df_text %>% unnest_tokens(word, "boilerplate") %>%

  count(word, sort=TRUE) %>%

  arrange(desc(n)) %>%

  mutate(rank = c(1:nrow(counts)), freq = n/sum(n))

  

word_list = df_text %>% unnest_tokens(word, "boilerplate") %>%

  anti_join(stop_words) %>%

  count(word, sort=TRUE) %>%

  filter(n >=500) %>%

  pull(word)

  

bag_of_words = df_text %>% unnest_tokens(word, "boilerplate") %>%

  filter(word %in% word_list) %>%

  count(ID, word) %>%

  pivot_wider(id_cols= ID, names_from=word, values_from=n) %>%

  map_df(replace_na, 0) %>%

  select(-ID)

  

odds_Evergreen = df %>%

  unnest_tokens(word, 'boilerplate') %>%

  filter(word %in% word_list) %>%

  count(label, word) %>%

  filter(n >=500) %>%

  pivot_wider(names_from = label, values_from = n) %>% 

  map_df(replace_na, 0.0001) %>%

  mutate(odds_Evergreen = `1`/`0`) %>%

  arrange(desc(odds_Evergreen)) %>%

  select(word, odds_Evergreen)

  

most_informative_words = combine(head(odds_Evergreen$word, 5), tail(odds_Evergreen$word, 5))

  

bag_of_words = df_text %>% unnest_tokens(word, "boilerplate") %>%

  anti_join(stop_words) %>%

  count(ID, word) %>%

  filter(word %in% most_informative_words) %>%

  pivot_wider(id_cols= ID, names_from=word, values_from=n) %>%

  right_join(outcome, by="ID") %>%

  map_df(replace_na, 0) %>%

  select(-ID)

  

write.csv(bag_of_words, "C:/Users/erao1/Desktop/RStudio Data/\\bag_of_words.csv", row.names= FALSE)

  

**Phase 3 Code:**

  

#LOAD#

library(readr)

source("C:/Users/lgarcia1/Desktop/QTM 3/BabsonAnalytics.R")

df <- read_csv("C:/Users/lgarcia1/Downloads/Phase 3.csv")

library(gmodels)

library(nnet)

library(caret)

library(NeuralNetTools)

#View(df)

  

#MANAGE#

df$url = NULL

df$urlid = NULL

df$boilerplate = NULL

df$hasDomainLink = as.factor(df$hasDomainLink)

df$is_news = as.factor(df$is_news) 

df$lengthyLinkDomain = as.factor(df$lengthyLinkDomain)

df$news_front_page = as.factor(df$news_front_page) 

df$alchemy_category = as.factor(df$alchemy_category)

df$alchemy_category_score = as.numeric(df$alchemy_category_score)

df$framebased = as.logical(df$framebased)

# filling in ? and NA # question mark could be another category (unknown)

df$alchemy_category_score[is.na(df$alchemy_category_score)] = 0 # any where alchemy category is 0 = it to an alchemy

df$label[is.na(df$label)] = 0

  

normalizer = preProcess(df, method=c("range"))

df = predict(normalizer, df)

  

#PARTITION#

N = nrow(df)

trainingSize = round(0.6*N)

trainingCases = sample(N, trainingSize) 

training = df[trainingCases, ]

test = df[-trainingCases, ]

  

  

#######################################

##    First Model : Logistic Regression   ##

#######################################

  

#MANAGE#

training$label = as.logical(training$label)

test$label = as.logical(test$label)

  

#BUILD#

modelGLM = glm(label ~ ., data=training, family=binomial)

predGLM = predict(modelGLM, test, type="response")

predTF = (predGLM>0.5)

  

modelstep = step(modelGLM)

predstep = predict(modelstep, test, type="response")

predTFstep= (predstep > 0.5)

  

summary(modelGLM)

summary(modelstep)

  

#EVALUATE#

observations = test$label

table(predTFstep, observations)

  

error_rate_GLM = sum(predTF != test$label)/nrow(test)

error_rate_GLMstep = sum(predTFstep != test$label)/nrow(test)

  

liftChart(test$label, predstep)

ROCChart(test$label, predstep)

liftChart(test$label, predGLM)

ROCChart(test$label,predGLM)

  

#######################################

##second Model : Classification Trees##

#######################################

library(rpart)

  

#MANAGE#

training$label = as.factor(training$label)

test$label = as.factor(test$label)

  

#BUILD#

stoppingRules = rpart.control(minsplit=2, minbucket = 1, cp = 0)

overfit = rpart(label~., data = training, control = stoppingRules)

pruned = easyPrune(overfit)

  

#PREDICT#

predTrees = predict(pruned, test, type="class")

  

#EVALUATE#

observations = test$label

table(predTrees, observations)

error_rate_Tree = sum(predTrees != observations)/nrow(test)

  

############################

##Third Model: Neural Nets##

############################

  

#MANAGE#

training$label = as.factor(training$label)

test$label = as.factor(test$label)

  

#BUILD#

modelnnet = nnet(`label`~ ., size = 4, data=training)

plotnet(modelnnet)

  

predNum = predict(modelnnet, test)

predNnet = predict(modelnnet,test, type = "class")

obs = test$`label`

  

table(predNnet, obs)

  

#EVAULATE#

error_rate_Nnet = sum(predNnet != obs)/nrow(test) 

error_bench = benchmarkErrorRate(training$`label`, obs)

  

#########################

##Fourth Model: Bagging##

#########################

library(randomForest)

  

#MANAGE#

training$label = as.logical(training$label)

test$label = as.logical(test$label)

  

#BUILD#

rf = randomForest(label~., data = training, ntree = 500)

predrf = predict(rf, test)

pred_rf = (predrf > 0.5)

  

#EVAULATE#

error_rate_bagging = sum(pred_rf != test$label)/nrow(test)

  

#########################

##    Fifth Model: Stacking   ##

#########################

  

#LOAD#

pred_glm_full = predict(modelstep, df, type = "response")

pred_trees_full = predict(pruned, df, type="class")

pred_nnet_full = predict(modelnnet, df, type = "class")

  

df_stacked = cbind(df, pred_glm_full, pred_trees_full, pred_nnet_full)

  

#PARTITION#

trainingStacked = df_stacked[trainingCases,] 

testStacked =  df_stacked[-trainingCases,]

  

#BUILD#

stacked = glm(label ~., data = trainingStacked, family = binomial)

pred_stacked = predict(stacked, testStacked, type = "response")

pred_stacked = (pred_stacked > 0.5)

  

#EVALUATE#

error_rate_stacked = sum(pred_stacked != testStacked$label) / nrow(testStacked)
```
